const emojipedia = [
  {
    id: 2,
    emoji: "🙏",
    name: "Person With Folded Hands",
    meaning:
      "Two hands pressed together. Is currently very introverted, saying a prayer, or hoping for enlightenment. Is also used as a “high five” or to say thank you."
  },
  {
    id: 3,
    emoji: "🤣",
    name: "Rolling On The Floor, Laughing",
    meaning:
      "This is funny! A smiley face, rolling on the floor, laughing. The face is laughing boundlessly. The emoji version of “rofl“. Stands for „rolling on the floor, laughing“."
  },
  {
    id: 4,
    emoji: "🤓",
    name: "Nerd Face",
    meaning:
      "Huge glasses, awkward smile and buck teeth. Used humorously or ironically for nerds or to express how smart you are. Stereotype of a nerd; a smart but funny-dressed person with social deficits."
  },
  {
    id: 1,
    emoji: "🦶 ",
    name: "Foot",
    meaning:
      "Finally walking barefoot again. You are standing on your own feet or would like to receive a foot massage from your sweetheart. Some like feet, others hate them, some have smelly feet and others have their feet well-tended. Our feet carry us and are the symbolic foundation of our body."
  }
];

export default emojipedia;
